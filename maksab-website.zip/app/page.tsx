import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, TrendingUp, Shield, CheckCircle, Star, Target, Globe } from "lucide-react"
import { MobileMenu } from "@/components/mobile-menu"
import { ScrollAnimation } from "@/components/scroll-animation"
import { ParallaxSection } from "@/components/parallax-section"
import { FloatingElements } from "@/components/floating-elements"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Enhanced Navigation with Scroll Effect */}
      <nav className="border-b border-gray-200 bg-white/95 backdrop-blur-sm sticky top-0 z-50 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <ScrollAnimation animation="fade-in-left">
              <div className="flex items-center">
                <Image src="/logo.png" alt="MAKSAB Logo" width={120} height={40} className="h-10 w-auto" />
              </div>
            </ScrollAnimation>
            <div className="hidden md:block">
              <ScrollAnimation animation="fade-in-up" delay={200}>
                <div className="ml-10 flex items-baseline space-x-8">
                  <Link
                    href="/"
                    className="text-maksab-blue hover:text-maksab-green font-medium transition-colors duration-300"
                  >
                    Home
                  </Link>
                  <Link
                    href="/about"
                    className="text-gray-600 hover:text-maksab-blue font-medium transition-colors duration-300"
                  >
                    About Us
                  </Link>
                  <Link
                    href="/services"
                    className="text-gray-600 hover:text-maksab-blue font-medium transition-colors duration-300"
                  >
                    Services
                  </Link>
                  <Link
                    href="/contact"
                    className="text-gray-600 hover:text-maksab-blue font-medium transition-colors duration-300"
                  >
                    Contact
                  </Link>
                </div>
              </ScrollAnimation>
            </div>
            <div className="flex items-center gap-4">
              <ScrollAnimation animation="fade-in-right" delay={300}>
                <Button className="hidden sm:block bg-maksab-blue hover:bg-maksab-blue/90 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl">
                  Get Started
                </Button>
              </ScrollAnimation>
              <MobileMenu currentPath="/" />
            </div>
          </div>
        </div>
      </nav>

      {/* Enhanced Hero Section with Background Image */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background Image with Overlay */}
        <div className="absolute inset-0">
          <Image src="/hero-bg.jpg" alt="Financial Success Background" fill className="object-cover" priority />
          <div className="absolute inset-0 bg-maksab-blue/80"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-maksab-blue/90 via-maksab-blue/70 to-transparent"></div>
        </div>

        {/* Floating Elements */}
        <FloatingElements />

        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8 text-white">
              <ScrollAnimation animation="fade-in-up" delay={500}>
                <div className="space-y-6">
                  <div className="inline-flex items-center px-4 py-2 bg-maksab-green/20 rounded-full text-sm font-medium text-maksab-green border border-maksab-green/30 backdrop-blur-sm">
                    <span className="w-2 h-2 bg-maksab-green rounded-full mr-2 animate-pulse"></span>
                    We connect the dots, going beyond expectations
                  </div>
                  <h1 className="text-4xl md:text-6xl font-bold leading-tight">
                    Connecting You to
                    <span className="block text-maksab-green">Financial Excellence</span>
                  </h1>
                  <p className="text-xl text-blue-100 leading-relaxed">
                    At MAKSAB, we focus on building meaningful connections with our clients, teams, and communities. We
                    help you achieve lasting improvements in financial performance while fostering excellence.
                  </p>
                </div>
              </ScrollAnimation>

              <ScrollAnimation animation="fade-in-up" delay={700}>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button
                    size="lg"
                    className="bg-maksab-green hover:bg-maksab-green/90 text-white transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl"
                  >
                    Start Your Journey
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-white text-white hover:bg-white hover:text-maksab-blue bg-transparent transform hover:scale-105 transition-all duration-300"
                  >
                    Discover Our Impact
                  </Button>
                </div>
              </ScrollAnimation>

              <ScrollAnimation animation="fade-in-up" delay={900}>
                {/* Trust Indicators */}
                <div className="flex items-center gap-6 pt-4">
                  <div className="flex items-center gap-2">
                    <div className="flex -space-x-2">
                      {[1, 2, 3, 4, 5].map((i) => (
                        <div
                          key={i}
                          className="w-8 h-8 bg-maksab-green rounded-full border-2 border-white flex items-center justify-center text-xs font-bold transform hover:scale-110 transition-transform duration-200"
                        >
                          {String.fromCharCode(64 + i)}
                        </div>
                      ))}
                    </div>
                    <span className="text-sm text-blue-100">Trusted by global leaders</span>
                  </div>
                </div>
              </ScrollAnimation>
            </div>

            <ScrollAnimation animation="fade-in-right" delay={600}>
              <div className="relative">
                <ParallaxSection speed={0.3}>
                  <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 transform hover:scale-105 transition-all duration-500 shadow-2xl">
                    <div className="grid grid-cols-2 gap-6">
                      <div className="text-center group">
                        <div className="text-3xl font-bold text-maksab-green group-hover:scale-110 transition-transform duration-300">
                          Global
                        </div>
                        <div className="text-sm text-blue-100">Network</div>
                      </div>
                      <div className="text-center group">
                        <div className="text-3xl font-bold text-maksab-green group-hover:scale-110 transition-transform duration-300">
                          Expert
                        </div>
                        <div className="text-sm text-blue-100">Advisory</div>
                      </div>
                      <div className="text-center group">
                        <div className="text-3xl font-bold text-maksab-green group-hover:scale-110 transition-transform duration-300">
                          Lasting
                        </div>
                        <div className="text-sm text-blue-100">Impact</div>
                      </div>
                      <div className="text-center group">
                        <div className="text-3xl font-bold text-maksab-green group-hover:scale-110 transition-transform duration-300">
                          Excellence
                        </div>
                        <div className="text-sm text-blue-100">Driven</div>
                      </div>
                    </div>
                  </div>
                </ParallaxSection>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Purpose & Mission Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fade-in-up">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Purpose & Mission</h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                We help clients achieve lasting, meaningful improvements in their performance while building a firm that
                attracts, develops, and retains top talent committed to financial excellence.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="fade-in-left" delay={200}>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-maksab-blue/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Target className="h-6 w-6 text-maksab-blue" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-maksab-blue mb-2">Our Mission</h3>
                    <p className="text-gray-600">
                      To help clients achieve distinctive, lasting improvements in their financial performance while
                      building a great firm that attracts, develops, and retains financial health.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-maksab-green/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Globe className="h-6 w-6 text-maksab-green" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-maksab-blue mb-2">Global Impact</h3>
                    <p className="text-gray-600">
                      By collaborating with leaders across the globe, we're making a positive impact that truly matters,
                      connecting with our clients, teams, and communities.
                    </p>
                  </div>
                </div>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="fade-in-right" delay={400}>
              <div className="bg-white rounded-2xl p-8 shadow-lg">
                <h3 className="text-2xl font-bold text-maksab-blue mb-6">What Sets Us Apart</h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-maksab-green flex-shrink-0" />
                    <span className="text-gray-700">Holistic solutions that create lasting value</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-maksab-green flex-shrink-0" />
                    <span className="text-gray-700">Relationships founded on trust and mutual respect</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-maksab-green flex-shrink-0" />
                    <span className="text-gray-700">Top-management approach for lasting impact</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-maksab-green flex-shrink-0" />
                    <span className="text-gray-700">Global network bringing the best of MAKSAB</span>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Core Values Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fade-in-up">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Core Values</h2>
              <p className="text-xl text-gray-600">
                Guided by strong values that shape our strategy and daily approach
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ScrollAnimation animation="fade-in-left" delay={200}>
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-500 transform hover:-translate-y-2 group">
                <CardHeader>
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 bg-maksab-blue/10 rounded-lg flex items-center justify-center">
                      <TrendingUp className="h-6 w-6 text-maksab-blue" />
                    </div>
                    <CardTitle className="text-maksab-blue">Improve Client Performance</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-maksab-green mt-1 flex-shrink-0" />
                      <span>Focus on holistic solutions that create value</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-maksab-green mt-1 flex-shrink-0" />
                      <span>Strengthen client capabilities for sustainable improvements</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-maksab-green mt-1 flex-shrink-0" />
                      <span>Introduce innovative management practices</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </ScrollAnimation>

            <ScrollAnimation animation="fade-in-right" delay={400}>
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-500 transform hover:-translate-y-2 group">
                <CardHeader>
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-12 h-12 bg-maksab-green/10 rounded-lg flex items-center justify-center">
                      <Shield className="h-6 w-6 text-maksab-green" />
                    </div>
                    <CardTitle className="text-maksab-blue">Highest Professional Standards</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-gray-600">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-maksab-green mt-1 flex-shrink-0" />
                      <span>Uphold ethical practices in all we do</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-maksab-green mt-1 flex-shrink-0" />
                      <span>Put clients' interests ahead of the firm's</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-maksab-green mt-1 flex-shrink-0" />
                      <span>Maintain independent and objective perspective</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fade-in-up">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">What We Do</h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                We provide comprehensive financial, business, risk, digital transformation, tax, and legal advisory
                services. We exist to make an impact that truly matters.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Financial Advisory",
                description:
                  "Navigate global shifts in behaviors and markets with innovative financial solutions for a better future.",
                delay: 100,
              },
              {
                title: "Business Consulting",
                description:
                  "Unlock your full potential by optimizing operations, strategies, and leadership for sustainable growth.",
                delay: 200,
              },
              {
                title: "Risk Advisory",
                description:
                  "Comprehensive risk services to identify, assess, and manage potential financial and operational risks.",
                delay: 300,
              },
              {
                title: "Digital Transformation",
                description:
                  "Guide businesses through adopting digital solutions that streamline operations and unlock growth.",
                delay: 400,
              },
              {
                title: "Transaction Advisory",
                description:
                  "Expert guidance for mergers, acquisitions, and complex deals with strategic insights and valuation.",
                delay: 500,
              },
              {
                title: "Tax Advisory",
                description:
                  "Navigate complex tax landscapes with strategies that optimize your position and ensure compliance.",
                delay: 600,
              },
            ].map((service, index) => (
              <ScrollAnimation key={index} animation="fade-in-up" delay={service.delay}>
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-500 hover:-translate-y-2 group cursor-pointer h-full">
                  <CardHeader>
                    <CardTitle className="text-maksab-blue group-hover:text-maksab-green transition-colors duration-300">
                      {service.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="group-hover:text-gray-700 transition-colors duration-300">
                      {service.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </ScrollAnimation>
            ))}
          </div>

          <ScrollAnimation animation="fade-in-up" delay={700}>
            <div className="text-center mt-12">
              <Link href="/services">
                <Button
                  size="lg"
                  className="bg-maksab-blue hover:bg-maksab-blue/90 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl"
                >
                  Explore All Services
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Client Testimonials */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fade-in-up">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Our Clients</h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto">
                We deliver trusted insights, expert advice, and in-depth analysis to leading organizations worldwide,
                empowering them to navigate complex business environments with confidence.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                quote:
                  "MAKSAB's holistic approach transformed our financial strategy and delivered exceptional results.",
                author: "Global Manufacturing Leader",
                role: "Chief Financial Officer",
                delay: 200,
              },
              {
                quote:
                  "Their digital transformation expertise helped us stay ahead in an increasingly competitive market.",
                author: "Technology Innovator",
                role: "Chief Executive Officer",
                delay: 400,
              },
              {
                quote:
                  "The risk advisory services provided invaluable insights that protected our business during uncertainty.",
                author: "Financial Services Firm",
                role: "Risk Management Director",
                delay: 600,
              },
            ].map((testimonial, index) => (
              <ScrollAnimation key={index} animation="scale-in" delay={testimonial.delay}>
                <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-500 transform hover:-translate-y-2 group">
                  <CardContent className="p-6">
                    <div className="flex mb-4">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className="w-5 h-5 text-yellow-400 fill-current group-hover:scale-110 transition-transform duration-200"
                          style={{ transitionDelay: `${i * 100}ms` }}
                        />
                      ))}
                    </div>
                    <p className="text-gray-600 mb-4 italic">"{testimonial.quote}"</p>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-maksab-blue to-maksab-green rounded-full flex items-center justify-center text-white font-bold group-hover:scale-110 transition-transform duration-300">
                        {testimonial.author
                          .split(" ")
                          .map((n) => n[0])
                          .join("")
                          .slice(0, 2)}
                      </div>
                      <div>
                        <div className="font-semibold text-maksab-blue">{testimonial.author}</div>
                        <div className="text-sm text-gray-500">{testimonial.role}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </ScrollAnimation>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced CTA Section with Parallax */}
      <section className="relative py-20 overflow-hidden">
        <ParallaxSection speed={0.5}>
          <div className="absolute inset-0 bg-gradient-to-r from-maksab-blue via-maksab-blue to-maksab-blue/90"></div>
        </ParallaxSection>

        <FloatingElements />

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
          <ScrollAnimation animation="scale-in">
            <div className="text-center space-y-8">
              <div className="space-y-4">
                <div className="inline-flex items-center px-4 py-2 bg-maksab-green/20 rounded-full text-sm font-medium text-maksab-green border border-maksab-green/30 backdrop-blur-sm">
                  <span className="w-2 h-2 bg-maksab-green rounded-full mr-2 animate-pulse"></span>
                  Ready to Connect the Dots?
                </div>
                <h2 className="text-3xl md:text-5xl font-bold">Let's Create Lasting Impact Together</h2>
                <p className="text-xl text-blue-100 max-w-3xl mx-auto">
                  Join leading organizations worldwide who trust MAKSAB to navigate complex challenges and achieve
                  meaningful, lasting improvements in performance.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
                <Link href="/contact">
                  <Button
                    size="lg"
                    className="bg-maksab-green hover:bg-maksab-green/90 transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl px-8 py-4 text-lg"
                  >
                    Start Your Journey
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
                <div className="flex items-center gap-4 text-blue-100">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-maksab-green" />
                    <span>Global expertise</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-maksab-green" />
                    <span>Lasting impact</span>
                  </div>
                </div>
              </div>

              {/* Social Proof */}
              <div className="pt-8 border-t border-white/20">
                <p className="text-blue-200 mb-4">Trusted by leading organizations worldwide</p>
                <div className="flex justify-center items-center gap-8 opacity-60">
                  {["Global Leaders", "Innovators", "Growth Companies", "Enterprises"].map((type, index) => (
                    <div
                      key={index}
                      className="px-4 py-2 bg-white/10 rounded-lg text-sm font-medium backdrop-blur-sm transform hover:scale-105 transition-all duration-300"
                    >
                      {type}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollAnimation animation="fade-in-up">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div>
                <Image
                  src="/logo.png"
                  alt="MAKSAB Logo"
                  width={120}
                  height={40}
                  className="h-10 w-auto mb-4 brightness-0 invert"
                />
                <p className="text-gray-400">
                  Connecting the dots to help you achieve more through meaningful partnerships and lasting impact.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-4">Quick Links</h3>
                <ul className="space-y-2 text-gray-400">
                  <li>
                    <Link href="/" className="hover:text-white transition-colors duration-300">
                      Home
                    </Link>
                  </li>
                  <li>
                    <Link href="/about" className="hover:text-white transition-colors duration-300">
                      About Us
                    </Link>
                  </li>
                  <li>
                    <Link href="/services" className="hover:text-white transition-colors duration-300">
                      Services
                    </Link>
                  </li>
                  <li>
                    <Link href="/contact" className="hover:text-white transition-colors duration-300">
                      Contact
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold mb-4">Advisory Services</h3>
                <ul className="space-y-2 text-gray-400">
                  <li>Financial Advisory</li>
                  <li>Business Consulting</li>
                  <li>Risk Advisory</li>
                  <li>Digital Transformation</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold mb-4">Contact Info</h3>
                <ul className="space-y-2 text-gray-400">
                  <li>Global Network</li>
                  <li>Expert Advisory</li>
                  <li>info@maksab.com</li>
                  <li>Lasting Impact</li>
                </ul>
              </div>
            </div>
          </ScrollAnimation>
          <ScrollAnimation animation="fade-in-up" delay={200}>
            <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
              <p>&copy; 2024 MAKSAB. Connecting the dots, going beyond expectations. All rights reserved.</p>
            </div>
          </ScrollAnimation>
        </div>
      </footer>
    </div>
  )
}
