"use client"

import type React from "react"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { MapPin, Phone, Mail, Clock } from "lucide-react"
import { useState } from "react"
import { motion } from "framer-motion"

const primaryColor = "rgb(var(--primary))"
const secondaryColor = "rgb(var(--secondary))"
const accentColor = "rgb(var(--accent))"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission here
    console.log("Form submitted:", formData)
    // You would typically send this data to your backend
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const fadeInAnimation = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.5, ease: "easeInOut" },
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link href="/">
                <Image src="/logo.png" alt="MAKSAB Logo" width={120} height={40} className="h-10 w-auto" />
              </Link>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-8">
                <Link href="/" className="text-gray-600 hover:text-primary font-medium">
                  Home
                </Link>
                <Link href="/about" className="text-gray-600 hover:text-primary font-medium">
                  About Us
                </Link>
                <Link href="/services" className="text-gray-600 hover:text-primary font-medium">
                  Services
                </Link>
                <Link href="/contact" className="text-primary hover:text-secondary font-medium">
                  Contact
                </Link>
              </div>
            </div>
            <Button className="bg-primary hover:bg-primary/90">Get Started</Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-primary/80 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">Contact Us</h1>
            <p className="text-xl text-blue-100 max-w-3xl mx-auto">
              Ready to take control of your financial future? Get in touch with our expert team today.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <motion.Card className="border-0 shadow-xl" variants={fadeInAnimation} initial="initial" animate="animate">
              <CardHeader>
                <CardTitle className="text-2xl text-primary">Send Us a Message</CardTitle>
                <CardDescription>Fill out the form below and we'll get back to you within 24 hours.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) => handleInputChange("firstName", e.target.value)}
                        required
                        className="transition-all duration-200 focus:ring-2 focus:ring-primary/50"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        value={formData.lastName}
                        onChange={(e) => handleInputChange("lastName", e.target.value)}
                        required
                        className="transition-all duration-200 focus:ring-2 focus:ring-primary/50"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      required
                      className="transition-all duration-200 focus:ring-2 focus:ring-primary/50"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                      className="transition-all duration-200 focus:ring-2 focus:ring-primary/50"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="service">Service of Interest</Label>
                    <Select onValueChange={(value) => handleInputChange("service", value)}>
                      <SelectTrigger className="transition-all duration-200 focus:ring-2 focus:ring-primary/50">
                        <SelectValue placeholder="Select a service" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="investment-management">Investment Management</SelectItem>
                        <SelectItem value="financial-planning">Financial Planning</SelectItem>
                        <SelectItem value="wealth-management">Wealth Management</SelectItem>
                        <SelectItem value="corporate-finance">Corporate Finance</SelectItem>
                        <SelectItem value="risk-management">Risk Management</SelectItem>
                        <SelectItem value="tax-planning">Tax Planning</SelectItem>
                        <SelectItem value="general-consultation">General Consultation</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Message</Label>
                    <Textarea
                      id="message"
                      rows={4}
                      value={formData.message}
                      onChange={(e) => handleInputChange("message", e.target.value)}
                      placeholder="Tell us about your financial goals and how we can help..."
                      className="transition-all duration-200 focus:ring-2 focus:ring-primary/50"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-primary hover:bg-primary/90 transition-all duration-200 hover:scale-105"
                  >
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </motion.Card>

            {/* Live Chat Widget */}
            <Card className="border-0 shadow-xl bg-gradient-to-br from-secondary to-secondary/90 text-white">
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                  <CardTitle className="text-white">Chat with an Expert</CardTitle>
                </div>
                <CardDescription className="text-green-100">
                  Get instant answers to your questions from our financial experts
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-white/10 rounded-lg p-3">
                    <p className="text-sm text-green-100">💬 "How can I start investing with $10,000?"</p>
                  </div>
                  <div className="bg-white/10 rounded-lg p-3">
                    <p className="text-sm text-green-100">💬 "What's the best retirement strategy for my age?"</p>
                  </div>
                  <Button className="w-full bg-white text-secondary hover:bg-gray-100 transform hover:scale-105 transition-all duration-200">
                    Start Live Chat
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Contact Information */}
            <motion.div className="space-y-8" variants={fadeInAnimation} initial="initial" animate="animate">
              <Card className="border-0 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-2xl text-primary">Get in Touch</CardTitle>
                  <CardDescription>
                    We're here to help you achieve your financial goals. Reach out to us through any of these channels.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <MapPin className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-primary mb-1">Office Address</h3>
                      <p className="text-gray-600">
                        123 Financial District
                        <br />
                        New York, NY 10004
                        <br />
                        United States
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Phone className="h-6 w-6 text-secondary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-primary mb-1">Phone Numbers</h3>
                      <p className="text-gray-600">
                        Main: +1 (555) 123-4567
                        <br />
                        Toll-Free: +1 (800) 123-4567
                        <br />
                        Fax: +1 (555) 123-4568
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Mail className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-primary mb-1">Email Addresses</h3>
                      <p className="text-gray-600">
                        General: info@maksab.com
                        <br />
                        New Clients: newclient@maksab.com
                        <br />
                        Support: support@maksab.com
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Clock className="h-6 w-6 text-secondary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-primary mb-1">Business Hours</h3>
                      <p className="text-gray-600">
                        Monday - Friday: 8:00 AM - 6:00 PM
                        <br />
                        Saturday: 9:00 AM - 2:00 PM
                        <br />
                        Sunday: Closed
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card className="border-0 shadow-xl bg-primary text-white">
                <CardHeader>
                  <CardTitle className="text-white">Schedule a Consultation</CardTitle>
                  <CardDescription className="text-blue-100">
                    Book a free 30-minute consultation with one of our financial advisors.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full bg-secondary hover:bg-secondary/90 text-white">
                    Book Free Consultation
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Visit Our Office</h2>
            <p className="text-xl text-gray-600">Located in the heart of New York's Financial District</p>
          </div>

          <div className="bg-gray-300 rounded-lg h-96 flex items-center justify-center">
            <div className="text-center">
              <MapPin className="h-12 w-12 text-gray-500 mx-auto mb-4" />
              <p className="text-gray-600 text-lg">Interactive Map Coming Soon</p>
              <p className="text-gray-500">123 Financial District, New York, NY 10004</p>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Appointment Booking */}
      <section className="py-20 bg-gradient-to-br from-primary to-primary/90 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Book Your Free Consultation</h2>
            <p className="text-xl text-blue-100">Choose a convenient time for your 30-minute financial consultation</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="text-primary">Available Time Slots</CardTitle>
                <CardDescription>Select your preferred date and time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-2 mb-6">
                  {["Mon 15", "Tue 16", "Wed 17", "Thu 18", "Fri 19", "Sat 20"].map((date, index) => (
                    <Button
                      key={index}
                      variant={index === 2 ? "default" : "outline"}
                      className={`text-sm transition-all duration-200 hover:scale-105 ${
                        index === 2 ? "bg-primary" : "border-primary text-primary hover:bg-primary hover:text-white"
                      }`}
                    >
                      {date}
                    </Button>
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {["9:00 AM", "10:30 AM", "2:00 PM", "3:30 PM"].map((time, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      className="border-secondary text-secondary hover:bg-secondary hover:text-white bg-transparent transition-all duration-200 hover:scale-105"
                    >
                      {time}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="text-primary">What to Expect</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-primary font-bold text-sm">1</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-primary">Financial Assessment</h4>
                    <p className="text-gray-600 text-sm">Review your current financial situation and goals</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-secondary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-secondary font-bold text-sm">2</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-primary">Strategy Discussion</h4>
                    <p className="text-gray-600 text-sm">Explore potential strategies and solutions</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                    <span className="text-primary font-bold text-sm">3</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-primary">Next Steps</h4>
                    <p className="text-gray-600 text-sm">Outline a clear path forward for your financial future</p>
                  </div>
                </div>
                <Button className="w-full bg-secondary hover:bg-secondary/90 mt-6 transition-all duration-200 hover:scale-105">
                  Confirm Appointment
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-gray-600">Common questions about our services and process</p>
          </div>

          <div className="space-y-6">
            {[
              {
                question: "What is the minimum investment amount?",
                answer:
                  "Our minimum investment varies by service. For investment management, we typically require a minimum of $100,000. However, we offer financial planning services starting at lower amounts. Contact us to discuss your specific situation.",
              },
              {
                question: "How do you charge for your services?",
                answer:
                  "Our fee structure is transparent and varies by service. Investment management typically uses an asset-based fee model, while financial planning may use hourly or project-based fees. We'll discuss all fees upfront during your consultation.",
              },
              {
                question: "How often will we meet to review my portfolio?",
                answer:
                  "We typically schedule quarterly reviews with our clients, though this can be adjusted based on your preferences and needs. We're also available for additional meetings as market conditions or your circumstances change.",
              },
              {
                question: "Are you a fiduciary?",
                answer:
                  "Yes, we are a registered investment advisor and act as a fiduciary. This means we are legally obligated to act in your best interests at all times and provide advice that is suitable for your specific situation.",
              },
              {
                question: "What makes MAKSAB different from other financial advisors?",
                answer:
                  "Our comprehensive approach combines investment management with holistic financial planning. We focus on building long-term relationships and provide personalized service with a dedicated team approach for each client.",
              },
            ].map((faq, index) => (
              <Card key={index} className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-primary">{faq.question}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <Image
                src="/logo.png"
                alt="MAKSAB Logo"
                width={120}
                height={40}
                className="h-10 w-auto mb-4 brightness-0 invert"
              />
              <p className="text-gray-400">Your trusted partner in financial success and wealth management.</p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/" className="hover:text-white">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/about" className="hover:text-white">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/services" className="hover:text-white">
                    Services
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Services</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Investment Management</li>
                <li>Financial Planning</li>
                <li>Wealth Management</li>
                <li>Corporate Finance</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Contact Info</h3>
              <ul className="space-y-2 text-gray-400">
                <li>123 Financial District</li>
                <li>New York, NY 10004</li>
                <li>+1 (555) 123-4567</li>
                <li>info@maksab.com</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 MAKSAB Financial Services. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
